package com.mygdx.game;

public class Virus {
    //position and dimension


    // characterics
    //name

    //health

    //block

    //buffs

    //debuffs

    //relics ?

    //potions ?


}
