package com.mygdx.game;

public class Enemy {
    //position and dimension


    // characterics
    //name

    //health

    //block

    //buffs

    //debuffs

    //intent
}
