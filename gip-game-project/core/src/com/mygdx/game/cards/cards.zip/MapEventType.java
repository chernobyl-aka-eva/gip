package com.mygdx.game.map;

public enum MapEventType {
    MONSTER,
    REST,
    RANDOM
}
